﻿// Initialize any jquery-ui-datepicker elements
$(function () {
    $(".jquery-ui-datepicker").datepicker();
});